

$(document).ready(function () {
    $.ajax({
        method: 'GET',
        url: 'https://06e97cea-6e67-4b32-b930-ab3442478e6f.bspapp.com/kf/get',
        dataType: 'json',
        success: function (res) {
            if(res.err_code==0){
                $('.kf').html(`${res.data.wx}`)
            }else{
                showFn(res.err_msg)
            }
        },
        error: function (err) {
           showFn(JSON.stringify(err))
        }
    })

    $.ajax({
        method: 'GET',
        url: 'https://06e97cea-6e67-4b32-b930-ab3442478e6f.bspapp.com/version/get',
        dataType: 'json',
        success: function (res) {
            if(res.err_code==0){
                if(res.data.version==version){
                    $('.isNewVersion').text(`已是最新版`)
                }else{
                    $('.isNewVersion').text(`有版本更新`)
                }
            }else{
                showFn(res.err_msg)
            }
        },
        error: function (err) {
           showFn(JSON.stringify(err))
        }
    })

    $.ajax({
        method: 'get',
        url: 'https://06e97cea-6e67-4b32-b930-ab3442478e6f.bspapp.com/url/get',
        dataType: 'json',
        data:{action:'get'},
        success: function (res) {
            if(res.err_code==0){
                $('.list p:eq(0)').on('click',function () {
                    chrome.tabs.create({url:res.data.helpUrl})
                })
                // $('.list p:eq(1)').click(function () {
                //     chrome.tabs.create({url:res.data[0].otherUrl})
                // })
                $('.list p:eq(2)').on('click',function () {
                    chrome.tabs.create({url:res.data.updataUrl})
                })
            }else{
                showFn(res.err_msg)
            }
        },
        error: function (err) {
           showFn(JSON.stringify(err))
        }
    })

    $.get(chrome.extension.getURL('manifest.json'),function (info) {
        version = info.version
        $('.curVersion').text(`(v ${version})`)
    },'json')

    let sTimer = null
   function showFn(msg='请输入完整信息'){
        clearTimeout(sTimer)
       $('.msg').text(msg).slideDown('slow',()=>{
           sTimer=setTimeout(()=>{
               $('.msg').slideToggle('slow')
               clearTimeout(sTimer)
           },3000)
       })

   }

    chrome.storage.sync.get(['user'], function (items) {
        let {user} = items
        if (!user) {

            $('.login').show()
            $('.goReg').on('click',function () {
                $('.login').hide()
                $('.reg').show()
            })

            $('.goLogin').on('click',function () {
                $('.login').show()
                $('.reg').hide()
            })


        }else{
            $('.index .nickname').text(`${user.account}(ID：${user.user_id==undefined?null:user.user_id})`)
            $('.index .expire').text(`${moment(user.expire).format('YYYY-MM-DD HH:mm:ss')}  到期`)
            $('.login').hide()
            $('.index').show()

        }
    })
    $('.confirmReg').on('click',() => {
        let account = $('.reg .account').val()
        let password = $('.reg .password').val()
        let password2 = $('.reg .password2').val()
        let invite = $('.reg .invite').val()
        let reg = /^[a-zA-Z][a-zA-Z0-9_]{2,11}$/

        if(!account.match(reg)){
            showFn('账号不能是纯数字或中文')
            return false
        }
        if (!account || account.length < 3 || account.length > 11) {
            showFn('请输入3-11位账号和密码')
            return false
        }
        if (!password || password.length < 6 || password.length > 16) {
            showFn('请输入6-16位密码')
            return false
        }
        if (!password2 || password2.length < 6 || password2.length > 16 || password !== password2) {
            showFn('两次输入的密码不一致')
            return false
        }



        $.ajax({
            method: 'get',
            url: 'https://06e97cea-6e67-4b32-b930-ab3442478e6f.bspapp.com/user',
            dataType: 'json',
            data: {
                account,password,password2,invite,action:'reg'
            },
            success: function (res) {
                if(res.err_code==0){
                    chrome.storage.sync.set({user:res.data},function () {
                        $('.reg').hide()
                        $('.index').show()
                        showFn('注册成功')
                        $.ajax({
                            method: 'get',
                            url: 'https://06e97cea-6e67-4b32-b930-ab3442478e6f.bspapp.com/version/get',
                            dataType: 'json',
                            success: function (res) {
                                if(res.err_code==0){
                                    if(res.data.version==version){
                                        $('.isNewVersion').text(`已是最新版`)
                                    }else{
                                        $('.isNewVersion').text(`有版本更新`)
                                    }
                                }else{
                                    showFn(res.err_msg)
                                }
                            },
                            error: function (err) {
                               showFn(JSON.stringify(err))
                            }
                        })

                        $.ajax({
                            method: 'get',
                            url: 'https://06e97cea-6e67-4b32-b930-ab3442478e6f.bspapp.com/url/get',
                            dataType: 'json',
                            success: function (res) {
                                if(res.err_code==0){
                                    console.log(res.data)
                                    $('.list p:eq(0)').on('click',function () {
                                        chrome.tabs.create({url:res.data.helpUrl})
                                    })
                                    // $('.list p:eq(1)').click(function () {
                                    //     chrome.tabs.create({url:res.data[0].otherUrl})
                                    // })
                                    $('.list p:eq(2)').on('click',function () {
                                        chrome.tabs.create({url:res.data.updataUrl})
                                    })
                                }else{
                                    showFn(res.err_msg)
                                }
                            },
                            error: function (err) {
                               showFn(JSON.stringify(err))
                            }
                        })
                        $('.index .nickname').text(`${res.data.account}(ID：${res.data.user_id==undefined?null:res.data.user_id})`)
                        $('.index .expire').text(`${moment(res.data.expire).format('YYYY-MM-DD')}  到期`)
                    })
                }else{
                    showFn(res.err_msg)
                }
            },
            error: function (err) {
               showFn(JSON.stringify(err))
            }
        })
    })
    $('.confirmLogin').on('click',()=>{
        let account = $('.login .account').val()
        let password = $('.login .password').val()
        if(account&&password&&account.length>=3&&password.length>=6){
            $.ajax({
                type: 'GET',
                url: 'https://06e97cea-6e67-4b32-b930-ab3442478e6f.bspapp.com/user',
                dataType: 'json',
                data: {
                    account,password,action:'login'
                },
                success: function (res) {
                    if(res.err_code==0){
                        chrome.storage.sync.set({user:res.data},function () {
                            $('.index .nickname').text(`${res.data.account}`)
                            $('.index .expire').text(`${moment(res.data.expire).format('YYYY-MM-DD HH:mm:ss')}  到期`)
                            $('.login').hide()
                            $('.index').show()
                            $.ajax({
                                method: 'GET',
                                url: 'https://06e97cea-6e67-4b32-b930-ab3442478e6f.bspapp.com/version/get',
                                dataType: 'json',
                                success: function (res) {
                                    if(res.err_code==0){
                                        if(res.data.version==version){
                                            $('.isNewVersion').text(`已是最新版`)
                                        }else{
                                            $('.isNewVersion').text(`有版本更新`)
                                        }
                                    }else{
                                        showFn(res.err_msg)
                                    }
                                },
                                error: function (err) {
                                   showFn(JSON.stringify(err))
                                }
                            })

                            $.ajax({
                                method: 'get',
                                url: 'https://06e97cea-6e67-4b32-b930-ab3442478e6f.bspapp.com/url/get',
                                dataType: 'json',
                                success: function (res) {
                                    if(res.err_code==0){
                                        console.log(res.data)
                                        $('.list p:eq(0)').on('click',function () {
                                            chrome.tabs.create({url:res.data.helpUrl})
                                        })
                                        // $('.list p:eq(1)').click(function () {
                                        //     chrome.tabs.create({url:res.data[0].otherUrl})
                                        // })
                                        $('.list p:eq(2)').on('click',function () {
                                            chrome.tabs.create({url:res.data.updataUrl})
                                        })
                                    }else{
                                        showFn(res.err_msg)
                                    }
                                },
                                error: function (err) {
                                   showFn(JSON.stringify(err))
                                }
                            })
                            showFn('登陆成功')
                        })
                    }else{
                        showFn(res.err_msg)
                    }
                },
                error: function (err) {
                    console.log(err)
                   showFn(JSON.stringify(err))
                }
            })
        }else{
            showFn()
        }
    })
    $('.list p:eq(1)').on('click',function () {
        $('.index').hide()
        $('.feedback').show()
    })

    $('.feedback_cancel').on('click',function () {
        $('.index').show()
        $('.feedback').hide()
    })

    $('.feedback_submit').on('click',function () {
        $.ajax({
            method: 'GET',
            url: 'https://06e97cea-6e67-4b32-b930-ab3442478e6f.bspapp.com/feedback/create',
            dataType: 'json',
            data:{
                title:$('.feedback_title').val(),
                content:$('.feedback_content').val(),
                contack:$('.feedback_contact').val()
            },
            success: function (res) {
                if(res.err_code==0){
                    showFn('提交反馈成功')
                    setTimeout(()=>{
                        $('.index').show()
                        $('.feedback').hide()
                    },2000)
                }else{
                    showFn(res.err_msg)
                }
            },
            error: function (err) {
               showFn(JSON.stringify(err))
            }
        })
    })

    $('.logout').on('click',function () {
        chrome.storage.sync.set({user:null},function () {
            $('.login').show()
            $('.index').hide()
            showFn('已退出登录')
        })
    })
})
