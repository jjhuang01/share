


$(document).ready(function () {
    let timer0 = null
    let timer = null
    let oHTML = `
        <div class="ws-box" style="background: rgba(255,218,184,0.4);margin-bottom: 10px;padding-left: 30px;padding-top: 20px;padding-bottom: 20px;display: flex;align-items: center">
           <label class="ws-seIpvUvHits" style="display:flex;align-items:center;margin-right: 20px;color: #333;font-size: 12px;">搜索人气 > <input style="margin-left:3px;height:30px;border: 1px solid #e6e6e6;width: 4em;text-align: center;" type="text" placeholder="0"></label>
           <label class="ws-onlineGoodsCnt" style="display:flex;align-items:center;margin-right: 20px;color: #333;font-size: 12px;">在线商品数 < <input style="margin-left:3px;height:30px;border: 1px solid #e6e6e6;width: 4em;text-align: center;" type="text" placeholder="0"></label>
           <label class="ws-payConvRate" style="display:flex;align-items:center;margin-right: 20px;color: #333;font-size: 12px;">支付转化率 > <input style="margin-left:3px;height:30px;border: 1px solid #e6e6e6;width: 4em;text-align: center;" type="text" placeholder="0"></label>
           <label class="ws-tmClickRatio" style="display:flex;align-items:center;margin-right: 20px;color: #333;font-size: 12px;">商城点击占比 < <input style="margin-left:3px;height:30px;border: 1px solid #e6e6e6;width: 4em;text-align: center;" type="text" placeholder="0"></label>
           <label class="ws-p4pAmt" style="display:flex;align-items:center;margin-right: 20px;color: #333;font-size: 12px;">直通车参考价 < <input style="margin-left:3px;height:30px;border: 1px solid #e6e6e6;width: 4em;text-align: center;" type="text" placeholder="0"></label>
           <button style="margin-right: 20px;margin-left:30px;cursor: pointer;background:#1890ff;
           min-width: 7em;height: 30px;text-align: center;color: #fff;" class="ws-setting-confirm">确定</button>
           <button style="margin-right: 20px;cursor: pointer;background: #ddd;width: 7em;height: 30px;text-align: center;" class="ws-settting-reset">重置</button>
        </div>
    `

    function init0(){
        // let el = $('.ebase-metaDecorator__root:not(:first)')
        let el = $('.ebase-metaDecorator-module__root:not(:first)')
        clearInterval(timer0)
        el.css('background,red')
        timer0 = setInterval(()=>{

            if(el){
                $('.ws-box').remove()
                el.after(oHTML)
                clearInterval(timer0)
            }else{
                // el = $('.ebase-metaDecorator__root:not(:first)')
                 el = $('.ebase-metaDecorator-module__root:not(:first)')
            }

        },100)

        // 初始化，点击不必要的选择

    }

    setTimeout(() => {
        init0()
    }, 1000);

    let oAlert = `
        <div id="ws-alert" style="height: 100vh;width: 100vw;background: rgba(0,0,0,0.5);display: flex;align-items: center;justify-content: center;position: fixed;left: 0;top: 0;z-index: 100001;">
            <div style="background: #fff;border-radius: 4px; min-width: 250px;">
                <h3 style="font-size: 18px;line-height: 50px;color: #999;text-indent: 10px;">生意参谋选品过滤助手</h3>
                <p id="msg" style="text-align: center;padding-top: 20px;padding-bottom: 20px;font-size: 16px;
                color: #666; 
                padding-right: 2em;
                padding-left: 2em;       
                border-top: 1px solid #f7f7f7;border-bottom: 1px solid #f7f7f7;">
                    这里显示信息
                </p>
                <div class="ws-confirm" style="cursor:pointer;color:#fff;font-size: 14px;
                border-bottom-left-radius: 4px;border-bottom-right-radius: 4px;
                display: flex;align-items: center;justify-content: 
                center;text-align: center;line-height: 50px;background:#1890ff;">
                    确定
                </div>
            </div>
        </div>
    `

    $('.ws-box:first label input').live('focus',function () {
        $('#msg').text('下方表格无该参数，请先勾选该参数再操作')

        clearTimeout(timer)
        timer = setTimeout(() => {
            let _text = $(this).parent().text().replace(/\<|>/, '')
            let _thText = $('table:first thead th').text()
            let _that = $(this)
            if (_thText.indexOf(_text.trim()) < 0) {
                $('#ws-alert').remove()
                $('#app').before(oAlert)
                $('#msg').text('下方表格无该参数，请先勾选该参数再操作')
                _that.val('')
                return false
            }
            _that.blur(function () {
                if (_thText.indexOf(_text.trim()) < 0) {
                    _that.val('')
                }

            })

            clearTimeout(timer)

        })
    })

    function init() {
        /*var seIpvUvHits = '' // 搜索人气
           var payConvRate = '' // 支付转化率
           var onlineGoodsCnt = '' //在线商品数
           var tmClickRatio = '' // 商城点击占比
           var p4pAmt = '' // 直通车参考价*/


        chrome.storage.sync.get(['user'],function (result) {
            let {user} = result
            if(!user){
                $('#ws-alert').remove()
                $('#app').before(oAlert)
                $('#msg').text('未登录')
                return false
            }else{
                let {expire} = user
                let _t = new Date(expire).getTime()
                let now = new Date().getTime()
                if(_t<now){
                    $('#ws-alert').remove()
                    $('#app').before(oAlert)
                    $('#msg').text('vip已到期，请联系客服续约')
                    return false
                }
                var seIpvUvHits_val = $('.ws-seIpvUvHits input').val()
                var payConvRate_val = $('.ws-payConvRate input').val()
                var onlineGoodsCnt_val = $('.ws-onlineGoodsCnt input').val()
                var tmClickRatio_val = $('.ws-tmClickRatio input').val()
                var p4pAmt_val = $('.ws-p4pAmt input').val()

                let tr = $('table:first tbody tr')
                let len = tr.length
                for (var i = 0; i < len; i++) {
                    if (seIpvUvHits_val && payConvRate_val && onlineGoodsCnt_val && tmClickRatio_val && p4pAmt_val) {
                        let seIpvUvHits = '' // 搜索人气
                        let payConvRate = '' // 支付转化率
                        let onlineGoodsCnt = '' //在线商品数
                        let tmClickRatio = '' // 商城点击占比
                        let p4pAmt = '' // 直通车参考价

                        let items = tr[i].querySelectorAll('.alife-dt-card-common-table-seIpvUvHits .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items.length; j++) {
                            if (items[j].innerHTML) {
                                seIpvUvHits = (items[j].innerHTML).replace(/\,/g, '')
                            }
                        }
                        let items2 = tr[i].querySelectorAll('.alife-dt-card-common-table-onlineGoodsCnt .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items2.length; j++) {
                            if (items2[j].innerHTML) {
                                onlineGoodsCnt = (items2[j].innerHTML).replace(/\,/g, '')
                            }
                        }
                        let items3 = tr[i].querySelectorAll('.alife-dt-card-common-table-payConvRate .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items3.length; j++) {
                            if (items3[j].innerHTML) {
                                payConvRate = (items3[j].innerHTML).replace(/\%/g, '')
                            }
                        }
                        let items4 = tr[i].querySelectorAll('.alife-dt-card-common-table-tmClickRatio .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items4.length; j++) {
                            if (items4[j].innerHTML) {
                                tmClickRatio = (items4[j].innerHTML).replace(/\%/g, '')
                            }
                        }
                        let items5 = tr[i].querySelectorAll('.alife-dt-card-common-table-p4pAmt .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items5.length; j++) {
                            if (items5[j].innerHTML) {
                                p4pAmt = (items5[j].innerHTML)
                            }
                        }

                        if (Number(seIpvUvHits) > seIpvUvHits_val && Number(payConvRate) > payConvRate_val && Number(onlineGoodsCnt) < onlineGoodsCnt_val && Number(tmClickRatio) < tmClickRatio_val && Number(p4pAmt) < p4pAmt_val) {
                            tr[i].style.background = '#fde1e1'
                        } else {
                            tr[i].style.background = '#fff'
                        }
                    }
                    else if (seIpvUvHits_val && payConvRate_val && onlineGoodsCnt_val && tmClickRatio_val) {
                        let seIpvUvHits = '' // 搜索人气
                        let payConvRate = '' // 支付转化率
                        let onlineGoodsCnt = '' //在线商品数
                        let tmClickRatio = '' // 商城点击占比

                        let items = tr[i].querySelectorAll('.alife-dt-card-common-table-seIpvUvHits .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items.length; j++) {
                            if (items[j].innerHTML) {
                                seIpvUvHits = (items[j].innerHTML).replace(/\,/g, '')
                            }
                        }
                        let items2 = tr[i].querySelectorAll('.alife-dt-card-common-table-onlineGoodsCnt .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items2.length; j++) {
                            if (items2[j].innerHTML) {
                                onlineGoodsCnt = (items2[j].innerHTML).replace(/\,/g, '')
                            }
                        }
                        let items3 = tr[i].querySelectorAll('.alife-dt-card-common-table-payConvRate .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items3.length; j++) {
                            if (items3[j].innerHTML) {
                                payConvRate = (items3[j].innerHTML).replace(/\%/g, '')
                            }
                        }
                        let items4 = tr[i].querySelectorAll('.alife-dt-card-common-table-tmClickRatio .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items4.length; j++) {
                            if (items4[j].innerHTML) {
                                tmClickRatio = (items4[j].innerHTML).replace(/\%/g, '')
                            }
                        }

                        if (Number(seIpvUvHits) > seIpvUvHits_val && Number(payConvRate) > payConvRate_val && Number(onlineGoodsCnt) < onlineGoodsCnt_val && Number(tmClickRatio) < tmClickRatio_val) {
                            tr[i].style.background = '#fde1e1'
                        } else {
                            tr[i].style.background = '#fff'
                        }
                    }
                    else if (seIpvUvHits_val && payConvRate_val && onlineGoodsCnt_val && p4pAmt_val) {
                        let seIpvUvHits = '' // 搜索人气
                        let payConvRate = '' // 支付转化率
                        let onlineGoodsCnt = '' //在线商品数
                        let p4pAmt = '' // 直通车参考价

                        let items = tr[i].querySelectorAll('.alife-dt-card-common-table-seIpvUvHits .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items.length; j++) {
                            if (items[j].innerHTML) {
                                seIpvUvHits = (items[j].innerHTML).replace(/\,/g, '')
                            }
                        }
                        let items2 = tr[i].querySelectorAll('.alife-dt-card-common-table-onlineGoodsCnt .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items2.length; j++) {
                            if (items2[j].innerHTML) {
                                onlineGoodsCnt = (items2[j].innerHTML).replace(/\,/g, '')
                            }
                        }
                        let items3 = tr[i].querySelectorAll('.alife-dt-card-common-table-payConvRate .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items3.length; j++) {
                            if (items3[j].innerHTML) {
                                payConvRate = (items3[j].innerHTML).replace(/\%/g, '')
                            }
                        }
                        let items5 = tr[i].querySelectorAll('.alife-dt-card-common-table-p4pAmt .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items5.length; j++) {
                            if (items5[j].innerHTML) {
                                p4pAmt = (items5[j].innerHTML)
                            }
                        }

                        if (Number(seIpvUvHits) > seIpvUvHits_val && Number(payConvRate) > payConvRate_val && Number(onlineGoodsCnt) < onlineGoodsCnt_val && Number(p4pAmt) < p4pAmt_val) {
                            tr[i].style.background = '#fde1e1'
                        } else {
                            tr[i].style.background = '#fff'
                        }
                    }
                    else if (seIpvUvHits_val && payConvRate_val && tmClickRatio_val && p4pAmt_val) {
                        let seIpvUvHits = '' // 搜索人气
                        let payConvRate = '' // 支付转化率
                        let tmClickRatio = '' // 商城点击占比
                        let p4pAmt = '' // 直通车参考价

                        let items = tr[i].querySelectorAll('.alife-dt-card-common-table-seIpvUvHits .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items.length; j++) {
                            if (items[j].innerHTML) {
                                seIpvUvHits = (items[j].innerHTML).replace(/\,/g, '')
                            }
                        }
                        let items3 = tr[i].querySelectorAll('.alife-dt-card-common-table-payConvRate .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items3.length; j++) {
                            if (items3[j].innerHTML) {
                                payConvRate = (items3[j].innerHTML).replace(/\%/g, '')
                            }
                        }
                        let items4 = tr[i].querySelectorAll('.alife-dt-card-common-table-tmClickRatio .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items4.length; j++) {
                            if (items4[j].innerHTML) {
                                tmClickRatio = (items4[j].innerHTML).replace(/\%/g, '')
                            }
                        }
                        let items5 = tr[i].querySelectorAll('.alife-dt-card-common-table-p4pAmt .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items5.length; j++) {
                            if (items5[j].innerHTML) {
                                p4pAmt = (items5[j].innerHTML)
                            }
                        }

                        if (Number(seIpvUvHits) > seIpvUvHits_val && Number(payConvRate) > payConvRate_val && Number(tmClickRatio) < tmClickRatio_val && Number(p4pAmt) < p4pAmt_val) {
                            tr[i].style.background = '#fde1e1'
                        } else {
                            tr[i].style.background = '#fff'
                        }
                    }
                    else if (seIpvUvHits_val && payConvRate_val && onlineGoodsCnt_val && tmClickRatio_val && p4pAmt_val) {
                        let seIpvUvHits = '' // 搜索人气
                        let onlineGoodsCnt = '' //在线商品数
                        let tmClickRatio = '' // 商城点击占比
                        let p4pAmt = '' // 直通车参考价

                        let items = tr[i].querySelectorAll('.alife-dt-card-common-table-seIpvUvHits .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items.length; j++) {
                            if (items[j].innerHTML) {
                                seIpvUvHits = (items[j].innerHTML).replace(/\,/g, '')
                            }
                        }
                        let items2 = tr[i].querySelectorAll('.alife-dt-card-common-table-onlineGoodsCnt .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items2.length; j++) {
                            if (items2[j].innerHTML) {
                                onlineGoodsCnt = (items2[j].innerHTML).replace(/\,/g, '')
                            }
                        }
                        let items4 = tr[i].querySelectorAll('.alife-dt-card-common-table-tmClickRatio .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items4.length; j++) {
                            if (items4[j].innerHTML) {
                                tmClickRatio = (items4[j].innerHTML).replace(/\%/g, '')
                            }
                        }
                        let items5 = tr[i].querySelectorAll('.alife-dt-card-common-table-p4pAmt .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items5.length; j++) {
                            if (items5[j].innerHTML) {
                                p4pAmt = (items5[j].innerHTML)
                            }
                        }

                        if (Number(seIpvUvHits) > seIpvUvHits_val && Number(onlineGoodsCnt) < onlineGoodsCnt_val && Number(tmClickRatio) < tmClickRatio_val && Number(p4pAmt) < p4pAmt_val) {
                            tr[i].style.background = '#fde1e1'
                        } else {
                            tr[i].style.background = '#fff'
                        }
                    }
                    else if (payConvRate_val && onlineGoodsCnt_val && tmClickRatio_val && p4pAmt_val) {
                        let payConvRate = '' // 支付转化率
                        let onlineGoodsCnt = '' //在线商品数
                        let tmClickRatio = '' // 商城点击占比
                        let p4pAmt = '' // 直通车参考价

                        let items2 = tr[i].querySelectorAll('.alife-dt-card-common-table-onlineGoodsCnt .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items2.length; j++) {
                            if (items2[j].innerHTML) {
                                onlineGoodsCnt = (items2[j].innerHTML).replace(/\,/g, '')
                            }
                        }
                        let items3 = tr[i].querySelectorAll('.alife-dt-card-common-table-payConvRate .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items3.length; j++) {
                            if (items3[j].innerHTML) {
                                payConvRate = (items3[j].innerHTML).replace(/\%/g, '')
                            }
                        }
                        let items4 = tr[i].querySelectorAll('.alife-dt-card-common-table-tmClickRatio .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items4.length; j++) {
                            if (items4[j].innerHTML) {
                                tmClickRatio = (items4[j].innerHTML).replace(/\%/g, '')
                            }
                        }
                        let items5 = tr[i].querySelectorAll('.alife-dt-card-common-table-p4pAmt .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items5.length; j++) {
                            if (items5[j].innerHTML) {
                                p4pAmt = (items5[j].innerHTML)
                            }
                        }

                        if (Number(payConvRate) > payConvRate_val && Number(onlineGoodsCnt) < onlineGoodsCnt_val && Number(tmClickRatio) < tmClickRatio_val && Number(p4pAmt) < p4pAmt_val) {
                            tr[i].style.background = '#fde1e1'
                        } else {
                            tr[i].style.background = '#fff'
                        }
                    }
                    else if (payConvRate_val && onlineGoodsCnt_val && tmClickRatio_val) {
                        let payConvRate = '' // 支付转化率
                        let onlineGoodsCnt = '' //在线商品数
                        let tmClickRatio = '' // 商城点击占比

                        let items2 = tr[i].querySelectorAll('.alife-dt-card-common-table-onlineGoodsCnt .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items2.length; j++) {
                            if (items2[j].innerHTML) {
                                onlineGoodsCnt = (items2[j].innerHTML).replace(/\,/g, '')
                            }
                        }
                        let items3 = tr[i].querySelectorAll('.alife-dt-card-common-table-payConvRate .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items3.length; j++) {
                            if (items3[j].innerHTML) {
                                payConvRate = (items3[j].innerHTML).replace(/\%/g, '')
                            }
                        }
                        let items4 = tr[i].querySelectorAll('.alife-dt-card-common-table-tmClickRatio .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items4.length; j++) {
                            if (items4[j].innerHTML) {
                                tmClickRatio = (items4[j].innerHTML).replace(/\%/g, '')
                            }
                        }

                        if (Number(payConvRate) > payConvRate_val && Number(onlineGoodsCnt) < onlineGoodsCnt_val && Number(tmClickRatio) < tmClickRatio_val) {
                            tr[i].style.background = '#fde1e1'
                        } else {
                            tr[i].style.background = '#fff'
                        }
                    }
                    else if (payConvRate_val && onlineGoodsCnt_val && p4pAmt_val) {
                        let payConvRate = '' // 支付转化率
                        let onlineGoodsCnt = '' //在线商品数
                        let p4pAmt = '' // 直通车参考价
                        let items2 = tr[i].querySelectorAll('.alife-dt-card-common-table-onlineGoodsCnt .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items2.length; j++) {
                            if (items2[j].innerHTML) {
                                onlineGoodsCnt = (items2[j].innerHTML).replace(/\,/g, '')
                            }
                        }
                        let items3 = tr[i].querySelectorAll('.alife-dt-card-common-table-payConvRate .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items3.length; j++) {
                            if (items3[j].innerHTML) {
                                payConvRate = (items3[j].innerHTML).replace(/\%/g, '')
                            }
                        }
                        let items5 = tr[i].querySelectorAll('.alife-dt-card-common-table-p4pAmt .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items5.length; j++) {
                            if (items5[j].innerHTML) {
                                p4pAmt = (items5[j].innerHTML)
                            }
                        }
                        if (Number(payConvRate) > payConvRate_val && Number(onlineGoodsCnt) < onlineGoodsCnt_val && Number(p4pAmt) < p4pAmt_val) {
                            tr[i].style.background = '#fde1e1'
                        } else {
                            tr[i].style.background = '#fff'
                        }
                    }
                    else if (payConvRate_val && tmClickRatio_val && p4pAmt_val) {

                        let payConvRate = '' // 支付转化率
                        let tmClickRatio = '' // 商城点击占比
                        let p4pAmt = '' // 直通车参考价

                        let items3 = tr[i].querySelectorAll('.alife-dt-card-common-table-payConvRate .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items3.length; j++) {
                            if (items3[j].innerHTML) {
                                payConvRate = (items3[j].innerHTML).replace(/\%/g, '')
                            }
                        }
                        let items4 = tr[i].querySelectorAll('.alife-dt-card-common-table-tmClickRatio .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items4.length; j++) {
                            if (items4[j].innerHTML) {
                                tmClickRatio = (items4[j].innerHTML).replace(/\%/g, '')
                            }
                        }
                        let items5 = tr[i].querySelectorAll('.alife-dt-card-common-table-p4pAmt .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items5.length; j++) {
                            if (items5[j].innerHTML) {
                                p4pAmt = (items5[j].innerHTML)
                            }
                        }

                        if (Number(payConvRate) > payConvRate_val && Number(tmClickRatio) < tmClickRatio_val && Number(p4pAmt) < p4pAmt_val) {
                            tr[i].style.background = '#fde1e1'
                        } else {
                            tr[i].style.background = '#fff'
                        }
                    }
                    else if (onlineGoodsCnt_val && tmClickRatio_val && p4pAmt_val) {
                        let onlineGoodsCnt = '' //在线商品数
                        let tmClickRatio = '' // 商城点击占比
                        let p4pAmt = '' // 直通车参考价

                        let items2 = tr[i].querySelectorAll('.alife-dt-card-common-table-onlineGoodsCnt .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items2.length; j++) {
                            if (items2[j].innerHTML) {
                                onlineGoodsCnt = (items2[j].innerHTML).replace(/\,/g, '')
                            }
                        }
                        let items4 = tr[i].querySelectorAll('.alife-dt-card-common-table-tmClickRatio .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items4.length; j++) {
                            if (items4[j].innerHTML) {
                                tmClickRatio = (items4[j].innerHTML).replace(/\%/g, '')
                            }
                        }
                        let items5 = tr[i].querySelectorAll('.alife-dt-card-common-table-p4pAmt .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items5.length; j++) {
                            if (items5[j].innerHTML) {
                                p4pAmt = (items5[j].innerHTML)
                            }
                        }

                        if (Number(onlineGoodsCnt) < onlineGoodsCnt_val && Number(tmClickRatio) < tmClickRatio_val && Number(p4pAmt) < p4pAmt_val) {
                            tr[i].style.background = '#fde1e1'
                        } else {
                            tr[i].style.background = '#fff'
                        }
                    }
                    else if (seIpvUvHits_val && payConvRate_val && onlineGoodsCnt_val) {
                        let seIpvUvHits = '' // 搜索人气
                        let payConvRate = '' // 支付转化率
                        let onlineGoodsCnt = '' //在线商品数

                        let items = tr[i].querySelectorAll('.alife-dt-card-common-table-seIpvUvHits .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items.length; j++) {
                            if (items[j].innerHTML) {
                                seIpvUvHits = (items[j].innerHTML).replace(/\,/g, '')
                            }
                        }
                        let items2 = tr[i].querySelectorAll('.alife-dt-card-common-table-onlineGoodsCnt .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items2.length; j++) {
                            if (items2[j].innerHTML) {
                                onlineGoodsCnt = (items2[j].innerHTML).replace(/\,/g, '')
                            }
                        }
                        let items3 = tr[i].querySelectorAll('.alife-dt-card-common-table-payConvRate .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items3.length; j++) {
                            if (items3[j].innerHTML) {
                                payConvRate = (items3[j].innerHTML).replace(/\%/g, '')
                            }
                        }


                        if (Number(seIpvUvHits) > seIpvUvHits_val && Number(payConvRate) > payConvRate_val && Number(onlineGoodsCnt) < onlineGoodsCnt_val) {
                            tr[i].style.background = '#fde1e1'
                        } else {
                            tr[i].style.background = '#fff'
                        }
                    }
                    else if (seIpvUvHits_val && payConvRate_val && tmClickRatio_val) {
                        let seIpvUvHits = '' // 搜索人气
                        let payConvRate = '' // 支付转化率
                        let tmClickRatio = '' // 商城点击占比

                        let items = tr[i].querySelectorAll('.alife-dt-card-common-table-seIpvUvHits .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items.length; j++) {
                            if (items[j].innerHTML) {
                                seIpvUvHits = (items[j].innerHTML).replace(/\,/g, '')
                            }
                        }

                        let items3 = tr[i].querySelectorAll('.alife-dt-card-common-table-payConvRate .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items3.length; j++) {
                            if (items3[j].innerHTML) {
                                payConvRate = (items3[j].innerHTML).replace(/\%/g, '')
                            }
                        }
                        let items4 = tr[i].querySelectorAll('.alife-dt-card-common-table-tmClickRatio .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items4.length; j++) {
                            if (items4[j].innerHTML) {
                                tmClickRatio = (items4[j].innerHTML).replace(/\%/g, '')
                            }
                        }
                        if (Number(seIpvUvHits) > seIpvUvHits_val && Number(payConvRate) > payConvRate_val && Number(tmClickRatio) < tmClickRatio_val) {
                            tr[i].style.background = '#fde1e1'
                        } else {
                            tr[i].style.background = '#fff'
                        }
                    }
                    else if (seIpvUvHits_val && payConvRate_val && p4pAmt_val) {
                        let seIpvUvHits = '' // 搜索人气
                        let payConvRate = '' // 支付转化率
                        let p4pAmt = '' // 直通车参考价

                        let items = tr[i].querySelectorAll('.alife-dt-card-common-table-seIpvUvHits .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items.length; j++) {
                            if (items[j].innerHTML) {
                                seIpvUvHits = (items[j].innerHTML).replace(/\,/g, '')
                            }
                        }
                        let items3 = tr[i].querySelectorAll('.alife-dt-card-common-table-payConvRate .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items3.length; j++) {
                            if (items3[j].innerHTML) {
                                payConvRate = (items3[j].innerHTML).replace(/\%/g, '')
                            }
                        }
                        let items5 = tr[i].querySelectorAll('.alife-dt-card-common-table-p4pAmt .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items5.length; j++) {
                            if (items5[j].innerHTML) {
                                p4pAmt = (items5[j].innerHTML)
                            }
                        }

                        if (Number(seIpvUvHits) > seIpvUvHits_val && Number(payConvRate) > payConvRate_val && Number(p4pAmt) < p4pAmt_val) {
                            tr[i].style.background = '#fde1e1'
                        } else {
                            tr[i].style.background = '#fff'
                        }
                    }
                    else if (seIpvUvHits_val && payConvRate_val) {
                        let seIpvUvHits = '' // 搜索人气
                        let payConvRate = '' // 支付转化率

                        let items = tr[i].querySelectorAll('.alife-dt-card-common-table-seIpvUvHits .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items.length; j++) {
                            if (items[j].innerHTML) {
                                seIpvUvHits = (items[j].innerHTML).replace(/\,/g, '')
                            }
                        }

                        let items3 = tr[i].querySelectorAll('.alife-dt-card-common-table-payConvRate .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items3.length; j++) {
                            if (items3[j].innerHTML) {
                                payConvRate = (items3[j].innerHTML).replace(/\%/g, '')
                            }
                        }

                        if (Number(seIpvUvHits) > seIpvUvHits_val && Number(payConvRate) > payConvRate_val) {
                            tr[i].style.background = '#fde1e1'
                        } else {
                            tr[i].style.background = '#fff'
                        }
                    }
                    else if (seIpvUvHits_val && onlineGoodsCnt_val) {
                        let seIpvUvHits = '' // 搜索人气
                        let onlineGoodsCnt = '' //在线商品数

                        let items = tr[i].querySelectorAll('.alife-dt-card-common-table-seIpvUvHits .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items.length; j++) {
                            if (items[j].innerHTML) {
                                seIpvUvHits = (items[j].innerHTML).replace(/\,/g, '')
                            }
                        }
                        let items2 = tr[i].querySelectorAll('.alife-dt-card-common-table-onlineGoodsCnt .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items2.length; j++) {
                            if (items2[j].innerHTML) {
                                onlineGoodsCnt = (items2[j].innerHTML).replace(/\,/g, '')
                            }
                        }

                        if (Number(seIpvUvHits) > seIpvUvHits_val && Number(onlineGoodsCnt) < onlineGoodsCnt_val) {
                            tr[i].style.background = '#fde1e1'
                        } else {
                            tr[i].style.background = '#fff'
                        }
                    }
                    else if (seIpvUvHits_val && tmClickRatio_val) {
                        let seIpvUvHits = '' // 搜索人气
                        let tmClickRatio = '' // 商城点击占比

                        let items = tr[i].querySelectorAll('.alife-dt-card-common-table-seIpvUvHits .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items.length; j++) {
                            if (items[j].innerHTML) {
                                seIpvUvHits = (items[j].innerHTML).replace(/\,/g, '')
                            }
                        }

                        let items4 = tr[i].querySelectorAll('.alife-dt-card-common-table-tmClickRatio .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items4.length; j++) {
                            if (items4[j].innerHTML) {
                                tmClickRatio = (items4[j].innerHTML).replace(/\%/g, '')
                            }
                        }

                        if (Number(seIpvUvHits) > seIpvUvHits_val && Number(tmClickRatio) < tmClickRatio_val) {
                            tr[i].style.background = '#fde1e1'
                        } else {
                            tr[i].style.background = '#fff'
                        }
                    }
                    else if (seIpvUvHits_val && p4pAmt_val) {
                        let seIpvUvHits = '' // 搜索人气
                        let p4pAmt = '' // 直通车参考价

                        let items = tr[i].querySelectorAll('.alife-dt-card-common-table-seIpvUvHits .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items.length; j++) {
                            if (items[j].innerHTML) {
                                seIpvUvHits = (items[j].innerHTML).replace(/\,/g, '')
                            }
                        }

                        let items5 = tr[i].querySelectorAll('.alife-dt-card-common-table-p4pAmt .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items5.length; j++) {
                            if (items5[j].innerHTML) {
                                p4pAmt = (items5[j].innerHTML)
                            }
                        }

                        if (Number(seIpvUvHits) > seIpvUvHits_val && Number(p4pAmt) < p4pAmt_val) {
                            tr[i].style.background = '#fde1e1'
                        } else {
                            tr[i].style.background = '#fff'
                        }
                    }
                    else if (payConvRate_val && onlineGoodsCnt_val) {

                        let payConvRate = '' // 支付转化率
                        let onlineGoodsCnt = '' //在线商品数

                        let items2 = tr[i].querySelectorAll('.alife-dt-card-common-table-onlineGoodsCnt .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items2.length; j++) {
                            if (items2[j].innerHTML) {
                                onlineGoodsCnt = (items2[j].innerHTML).replace(/\,/g, '')
                            }
                        }
                        let items3 = tr[i].querySelectorAll('.alife-dt-card-common-table-payConvRate .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items3.length; j++) {
                            if (items3[j].innerHTML) {
                                payConvRate = (items3[j].innerHTML).replace(/\%/g, '')
                            }
                        }

                        if (Number(payConvRate) > payConvRate_val && Number(onlineGoodsCnt) < onlineGoodsCnt_val) {
                            tr[i].style.background = '#fde1e1'
                        } else {
                            tr[i].style.background = '#fff'
                        }
                    }
                    else if (payConvRate_val && tmClickRatio_val) {
                        let payConvRate = '' // 支付转化率
                        let tmClickRatio = '' // 商城点击占比

                        let items3 = tr[i].querySelectorAll('.alife-dt-card-common-table-payConvRate .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items3.length; j++) {
                            if (items3[j].innerHTML) {
                                payConvRate = (items3[j].innerHTML).replace(/\%/g, '')
                            }
                        }
                        let items4 = tr[i].querySelectorAll('.alife-dt-card-common-table-tmClickRatio .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items4.length; j++) {
                            if (items4[j].innerHTML) {
                                tmClickRatio = (items4[j].innerHTML).replace(/\%/g, '')
                            }
                        }

                        if (Number(payConvRate) > payConvRate_val && Number(tmClickRatio) < tmClickRatio_val) {
                            tr[i].style.background = '#fde1e1'
                        } else {
                            tr[i].style.background = '#fff'
                        }
                    }
                    else if (payConvRate_val && p4pAmt_val) {

                        let payConvRate = '' // 支付转化率
                        let p4pAmt = '' // 直通车参考价

                        let items3 = tr[i].querySelectorAll('.alife-dt-card-common-table-payConvRate .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items3.length; j++) {
                            if (items3[j].innerHTML) {
                                payConvRate = (items3[j].innerHTML).replace(/\%/g, '')
                            }
                        }
                        let items5 = tr[i].querySelectorAll('.alife-dt-card-common-table-p4pAmt .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items5.length; j++) {
                            if (items5[j].innerHTML) {
                                p4pAmt = (items5[j].innerHTML)
                            }
                        }

                        if (Number(payConvRate) > payConvRate_val && Number(p4pAmt) < p4pAmt_val) {
                            tr[i].style.background = '#fde1e1'
                        } else {
                            tr[i].style.background = '#fff'
                        }
                    }
                    else if (onlineGoodsCnt_val && tmClickRatio_val) {

                        let onlineGoodsCnt = '' //在线商品数
                        let tmClickRatio = '' // 商城点击占比

                        let items2 = tr[i].querySelectorAll('.alife-dt-card-common-table-onlineGoodsCnt .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items2.length; j++) {
                            if (items2[j].innerHTML) {
                                onlineGoodsCnt = (items2[j].innerHTML).replace(/\,/g, '')
                            }
                        }

                        let items4 = tr[i].querySelectorAll('.alife-dt-card-common-table-tmClickRatio .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items4.length; j++) {
                            if (items4[j].innerHTML) {
                                tmClickRatio = (items4[j].innerHTML).replace(/\%/g, '')
                            }
                        }

                        if (Number(onlineGoodsCnt) < onlineGoodsCnt_val && Number(tmClickRatio) < tmClickRatio_val) {
                            tr[i].style.background = '#fde1e1'
                        } else {
                            tr[i].style.background = '#fff'
                        }
                    }
                    else if (onlineGoodsCnt_val && p4pAmt_val) {

                        let onlineGoodsCnt = '' //在线商品数
                        let p4pAmt = '' // 直通车参考价


                        let items2 = tr[i].querySelectorAll('.alife-dt-card-common-table-onlineGoodsCnt .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items2.length; j++) {
                            if (items2[j].innerHTML) {
                                onlineGoodsCnt = (items2[j].innerHTML).replace(/\,/g, '')
                            }
                        }
                        let items5 = tr[i].querySelectorAll('.alife-dt-card-common-table-p4pAmt .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items5.length; j++) {
                            if (items5[j].innerHTML) {
                                p4pAmt = (items5[j].innerHTML)
                            }
                        }

                        if (Number(onlineGoodsCnt) < onlineGoodsCnt_val && Number(p4pAmt) < p4pAmt_val) {
                            tr[i].style.background = '#fde1e1'
                        } else {
                            tr[i].style.background = '#fff'
                        }
                    }
                    else if (tmClickRatio_val && p4pAmt_val) {
                        let tmClickRatio = '' // 商城点击占比
                        let p4pAmt = '' // 直通车参考价


                        let items4 = tr[i].querySelectorAll('.alife-dt-card-common-table-tmClickRatio .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items4.length; j++) {
                            if (items4[j].innerHTML) {
                                tmClickRatio = (items4[j].innerHTML).replace(/\%/g, '')
                            }
                        }
                        let items5 = tr[i].querySelectorAll('.alife-dt-card-common-table-p4pAmt .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items5.length; j++) {
                            if (items5[j].innerHTML) {
                                p4pAmt = (items5[j].innerHTML)
                            }
                        }

                        if (Number(tmClickRatio) < tmClickRatio_val && Number(p4pAmt) < p4pAmt_val) {
                            tr[i].style.background = '#fde1e1'
                        } else {
                            tr[i].style.background = '#fff'
                        }
                    }
                    else if (seIpvUvHits_val) {
                        let seIpvUvHits = '' // 搜索人气

                        let items = tr[i].querySelectorAll('.alife-dt-card-common-table-seIpvUvHits .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items.length; j++) {
                            if (items[j].innerHTML) {
                                seIpvUvHits = (items[j].innerHTML).replace(/\,/g, '')
                            }
                        }
                        if (Number(seIpvUvHits) > seIpvUvHits_val) {
                            tr[i].style.background = '#fde1e1'
                        } else {
                            tr[i].style.background = '#fff'
                        }
                    }
                    else if (payConvRate_val) {
                        let payConvRate = '' // 支付转化率

                        let items3 = tr[i].querySelectorAll('.alife-dt-card-common-table-payConvRate .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items3.length; j++) {
                            if (items3[j].innerHTML) {
                                payConvRate = (items3[j].innerHTML).replace(/\%/g, '')
                            }
                        }

                        if (Number(payConvRate) > payConvRate_val) {
                            tr[i].style.background = '#fde1e1'
                        } else {
                            tr[i].style.background = '#fff'
                        }
                    }
                    else if (onlineGoodsCnt_val) {

                        let onlineGoodsCnt = '' //在线商品数

                        let items2 = tr[i].querySelectorAll('.alife-dt-card-common-table-onlineGoodsCnt .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items2.length; j++) {
                            if (items2[j].innerHTML) {
                                onlineGoodsCnt = (items2[j].innerHTML).replace(/\,/g, '')
                            }
                        }

                        if (Number(onlineGoodsCnt) < onlineGoodsCnt_val) {
                            tr[i].style.background = '#fde1e1'
                        } else {
                            tr[i].style.background = '#fff'
                        }
                    }
                    else if (tmClickRatio_val) {

                        let tmClickRatio = '' // 商城点击占比

                        let items4 = tr[i].querySelectorAll('.alife-dt-card-common-table-tmClickRatio .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items4.length; j++) {
                            if (items4[j].innerHTML) {
                                tmClickRatio = (items4[j].innerHTML).replace(/\%/g, '')
                            }
                        }

                        if (Number(tmClickRatio) < tmClickRatio_val) {
                            tr[i].style.background = '#fde1e1'
                        } else {
                            tr[i].style.background = '#fff'
                        }
                    }
                    else if (p4pAmt_val) {
                        let p4pAmt = '' // 直通车参考价

                        let items5 = tr[i].querySelectorAll('.alife-dt-card-common-table-p4pAmt .alife-dt-card-common-table-sortable-value span')
                        for (let j = 0; j < items5.length; j++) {
                            if (items5[j].innerHTML) {
                                p4pAmt = (items5[j].innerHTML)
                            }
                        }

                        if (Number(p4pAmt) < p4pAmt_val) {
                            tr[i].style.background = '#fde1e1'
                        } else {
                            tr[i].style.background = '#fff'
                        }
                    }else{
                        tr[i].style.background = '#fff'
                    }
                }

            }

        })



    }

   
    let ClickFn = ()=>{
        let text1 = (($('.ws-seIpvUvHits').text()).replace(/\<|>/, '')).trim()
        let text2 = (($('.ws-onlineGoodsCnt').text()).replace(/\<|>/, '')).trim()
        let text3 = (($('.ws-payConvRate').text()).replace(/\<|>/, '')).trim()
        let text4 = (($('.ws-tmClickRatio').text()).replace(/\<|>/, '')).trim()
        let text5 = (($('.ws-p4pAmt').text()).replace(/\<|>/, '')).trim()
        
        let _thText = $('table:first thead th').text()
        // console.log(_thText)
      
        if(_thText.indexOf(text1) < 0){$('.ws-seIpvUvHits input').val('')}
        if(_thText.indexOf(text2) < 0){$('.ws-onlineGoodsCnt input').val('')}
        if(_thText.indexOf(text3) < 0){$('.ws-payConvRate input').val('')}
        if(_thText.indexOf(text4) < 0){$('.ws-tmClickRatio input').val('')}
        if(_thText.indexOf(text5) < 0){$('.ws-p4pAmt input').val('')}

        init()
    }

    $('.item-search input').bind('keypress',()=>{
        document.querySelector('.oui-table-wrapper').addEventListener('DOMNodeRemoved',function(){
            ClickFn()
         })
    })
    $('div.op-mc-search-input-item-component').live('click',function(){
        document.querySelector('.oui-table-wrapper').addEventListener('DOMNodeRemoved',function(){
            ClickFn()
         })
    })

    /**
     * 点击确定按钮
     */
    $('.ws-setting-confirm').live('click', function (event) {
        ClickFn()
    })

    $('.ws-settting-reset').live('click',function (event) {
        $('.ws-box label input').val('')
        init()
    })
    // $('.ws-box').live('click',function () {
    //     console.log($('table').find('th').text().indexOf('点击率'))
    // })

    $('.ws-confirm').live('click', function (event) {
        event.stopPropagation();
        $('#ws-alert').remove()
    })
    $('.oui-index-picker-content li').live('click', function () {
        init()
    })
    $('.ant-pagination.oui-pagination').live('click',function () {
        init()
    })
    $('.oui-tab-switch .oui-tab-switch-item').live('click',function () {
        init0()
        init()
        setTimeout(() => {
            $("ul.oui-index-picker-list li:not(:eq(0)) .ant-checkbox-checked").parent('label').click()
        }, 500);
    })
    setTimeout(() => {
        $("ul.oui-index-picker-list li:not(:eq(0)) .ant-checkbox-checked").parent('label').click()
    }, 500);

})

